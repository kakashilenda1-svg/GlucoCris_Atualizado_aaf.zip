package com.agon.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.formatDate
import com.agon.app.data.toMgDl
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun GlucoseChart(entries: List<GlucoseEntry>, low: Int, high: Int, days: Int = 7) {
    val g = glucoColors()
    val cutoff = System.currentTimeMillis() - days.toLong() * 24L * 60L * 60L * 1000L
    val points = entries.filter { it.at >= cutoff }.sortedBy { it.at }
    if (points.isEmpty()) {
        Text("Sem medições para o gráfico.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
        return
    }
    val values = points.map { toMgDl(it.value, it.unit) }
    val minV = minOf(values.min(), low.toDouble()) - 15
    val maxV = maxOf(values.max(), high.toDouble()) + 15
    Canvas(Modifier.fillMaxWidth().height(160.dp).padding(vertical = 6.dp)) {
        val w = size.width
        val h = size.height
        fun yOf(v: Double) = (h - ((v - minV) / (maxV - minV)) * h).toFloat()
        val yLow = yOf(low.toDouble())
        val yHigh = yOf(high.toDouble())
        drawRect(g.chartBand, topLeft = Offset(0f, yHigh), size = androidx.compose.ui.geometry.Size(w, yLow - yHigh))
        val path = Path()
        points.forEachIndexed { i, e ->
            val x = if (points.size == 1) w / 2 else w * i / (points.size - 1)
            val y = yOf(toMgDl(e.value, e.unit))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, g.violet, style = Stroke(width = 4f, cap = StrokeCap.Round))
        points.forEachIndexed { i, e ->
            val x = if (points.size == 1) w / 2 else w * i / (points.size - 1)
            val mg = toMgDl(e.value, e.unit)
            val color = when {
                mg < low -> g.orange
                mg > high -> g.red
                else -> g.green
            }
            drawCircle(color, radius = 7f, center = Offset(x, yOf(mg)))
        }
    }
    Text(
        "Faixa verde: meta de $low–$high · ${points.size} medições · de ${formatDate(points.first().at)}",
        color = g.muted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
    )
}

fun roundMg(v: Double): Int = v.roundToInt()
