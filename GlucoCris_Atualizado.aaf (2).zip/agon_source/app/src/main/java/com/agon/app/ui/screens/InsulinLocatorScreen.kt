package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors
import com.agon.app.data.CrisPrefs
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

private enum class EstCategory(val label: String) {
    TODOS("Todos os locais"),
    POSTO("Postos de saúde (UBS)"),
    FARMACIA_PUBLICA("Farmácias públicas"),
    FARMACIA_PARTICULAR("Farmácias particulares"),
    FARMACIA_POPULAR("Farmácia Popular"),
}

/**
 * Guias de busca — NÃO são estabelecimentos com telefone confirmado.
 * Orientam o usuário a canais oficiais reais.
 */
private data class SearchGuide(
    val id: String,
    val title: String,
    val category: EstCategory,
    val howToFind: String,
    val officialHint: String,
    val webSearchQuery: String,
    val relatedInsulins: List<String>,
)

private val SEARCH_GUIDES = listOf(
    SearchGuide(
        "g1",
        "UBS / Posto de saúde no seu município",
        EstCategory.POSTO,
        "Busque “UBS + nome do seu bairro/município” ou use o app/site da prefeitura e da Secretaria Municipal de Saúde.",
        "Telefone e horário oficiais estão no site da prefeitura ou no CNES (Cadastro Nacional de Estabelecimentos de Saúde).",
        "UBS posto de saúde telefone",
        listOf("Insulina Humana Regular", "Insulina Humana NPH"),
    ),
    SearchGuide(
        "g2",
        "Farmácia pública / dispensação do SUS",
        EstCategory.FARMACIA_PUBLICA,
        "Consulte a Secretaria Municipal ou Estadual de Saúde sobre farmácias de alto custo e dispensação de insulinas do componente especializado.",
        "Use o telefone da secretaria de saúde do seu município/estado (números oficiais nos portais .gov.br).",
        "farmácia pública SUS insulina telefone secretaria saúde",
        listOf("Insulina Humana Regular", "Insulina Humana NPH", "Análogos conforme protocolo local"),
    ),
    SearchGuide(
        "g3",
        "Programa Farmácia Popular",
        EstCategory.FARMACIA_POPULAR,
        "Estabelecimentos credenciados vendem medicamentos do elenco com desconto. Confira no site oficial do programa quais farmácias participam na sua cidade.",
        "Portal oficial do Programa Farmácia Popular (governo federal) e consulta por município.",
        "Farmácia Popular credenciada telefone",
        listOf("Conforme elenco vigente do programa"),
    ),
    SearchGuide(
        "g4",
        "Farmácias particulares da sua região",
        EstCategory.FARMACIA_PARTICULAR,
        "Pesquise a rede de farmácias da sua cidade, ligue e confirme a apresentação exata (marca, concentração, caneta/frasco) e o estoque do dia.",
        "Use o site ou telefone oficiais da farmácia. Não confie em números genéricos de listagens desatualizadas.",
        "farmácia insulina glargina lispro telefone",
        listOf("Lispro", "Asparte", "Glulisina", "Glargina", "Detemir", "Degludeca"),
    ),
)

private val INSULIN_TYPES_EDU = listOf(
    "Insulina humana Regular — geralmente de ação curta",
    "Insulina humana NPH — geralmente de ação intermediária",
    "Análogos de ação rápida/ultrarrápida (lispro, asparte, glulisina)",
    "Análogos de ação prolongada/basal (glargina, detemir, degludeca)",
    "Pré-misturas e outras formulações oficialmente reconhecidas",
)

private val BRAZIL_STATES = listOf(
    "Todos", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO",
    "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI",
    "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
)

@Composable
fun InsulinLocatorScreen(nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current

    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(EstCategory.TODOS) }
    var stateFilter by remember { mutableStateOf("Todos") }
    var cityFilter by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        val mem = CrisPrefs.loadMemory(context)
        if (mem.lastLocatorCity.isNotBlank()) cityFilter = mem.lastLocatorCity
        if (mem.lastLocatorState.isNotBlank()) stateFilter = mem.lastLocatorState
    }

    val results = remember(query, category) {
        SEARCH_GUIDES.filter { guide ->
            val matchCat = category == EstCategory.TODOS || guide.category == category
            val matchQuery = query.isBlank() ||
                guide.title.contains(query, ignoreCase = true) ||
                guide.relatedInsulins.any { it.contains(query, ignoreCase = true) } ||
                guide.howToFind.contains(query, ignoreCase = true)
            matchCat && matchQuery
        }
    }

    fun openWebSearch(baseQuery: String) {
        val parts = mutableListOf(baseQuery)
        if (cityFilter.isNotBlank()) parts.add(cityFilter.trim())
        if (stateFilter != "Todos") parts.add(stateFilter)
        val q = Uri.encode(parts.joinToString(" "))
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q"))
        context.startActivity(intent)
    }

    fun openOfficialPortal(kind: EstCategory) {
        val url = when (kind) {
            EstCategory.FARMACIA_POPULAR ->
                "https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/f/farmacia-popular"
            EstCategory.POSTO, EstCategory.FARMACIA_PUBLICA ->
                "https://www.gov.br/saude/pt-br"
            else ->
                "https://www.google.com/search?q=" + Uri.encode(
                    buildString {
                        append("farmácia insulina")
                        if (cityFilter.isNotBlank()) append(" $cityFilter")
                        if (stateFilter != "Todos") append(" $stateFilter")
                    },
                )
        }
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    ScrollScreen {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "← Voltar",
                color = g.violet,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.clickable { nav.popBackStack() },
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("Localizador de Insulinas 💉", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text(
            "Orientação nacional — confirme sempre no canal oficial do estabelecimento",
            color = g.muted,
            fontSize = 13.sp,
        )

        GCard(Modifier.padding(top = 12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.Info, null, tint = g.orange, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        "Este app não inventa telefones nem confirma estoque.",
                        color = g.ink,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                    Text(
                        "Não existe base pública confiável e atualizada com telefone + estoque de insulina de todas as farmácias e UBS do Brasil. Use os atalhos abaixo para buscar no site oficial ou na web e ligar com o número que o próprio estabelecimento publicar.",
                        color = g.muted,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        GField(
            "Buscar insulina, princípio ativo ou tipo de local",
            query,
            { query = it },
            "Ex: glargina, NPH, UBS, Farmácia Popular…",
        )

        Text("Categoria", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
        ChipRow(
            EstCategory.entries.map { it.name to it.label },
            category.name,
        ) { key ->
            category = EstCategory.entries.first { it.name == key }
        }

        Text("Estado (UF) — melhora a busca na web", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        ChipRow(
            BRAZIL_STATES.map { it to it },
            stateFilter,
        ) { stateFilter = it }

        GField("Município (recomendado)", cityFilter, {
            cityFilter = it
            scope.launch {
                val mem = CrisPrefs.loadMemory(context)
                CrisPrefs.saveMemory(context, mem.copy(lastLocatorCity = it, lastLocatorState = stateFilter))
            }
        }, "Ex: Campinas, Ribeirão Preto…")

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            PrimaryButton("Limpar", g.muted, {
                query = ""
                category = EstCategory.TODOS
                stateFilter = "Todos"
                cityFilter = ""
            }, Modifier.weight(1f))
            PrimaryButton(
                if (showInfo) "Ocultar tipos" else "Tipos de insulina",
                g.violetDeep,
                { showInfo = !showInfo },
                Modifier.weight(1f),
            )
        }

        if (showInfo) {
            GCard(Modifier.padding(top = 10.dp)) {
                Text("Classificação educativa", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Não recomenda dose, horário, troca ou tratamento. Início, pico e duração variam conforme formulação e orientação profissional.",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
                INSULIN_TYPES_EDU.forEach {
                    Text("• $it", color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }

        Text("Canais oficiais", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp))
        GCard(Modifier.padding(top = 6.dp)) {
            Text("Abrir portais para consultar estabelecimentos reais", color = g.muted, fontSize = 12.sp)
            PrimaryButton("Portal Farmácia Popular (gov.br)", g.violet, {
                openOfficialPortal(EstCategory.FARMACIA_POPULAR)
            }, Modifier.padding(top = 8.dp))
            PrimaryButton("Ministério da Saúde (gov.br)", g.blue, {
                openOfficialPortal(EstCategory.POSTO)
            }, Modifier.padding(top = 8.dp))
            PrimaryButton(
                "Buscar na web: insulina + meu município",
                g.violetDeep,
                {
                    openWebSearch(
                        buildString {
                            append("insulina farmácia OR UBS")
                            if (query.isNotBlank()) append(" $query")
                        },
                    )
                },
                Modifier.padding(top = 8.dp),
            )
        }

        Text(
            "${results.size} orientação(ões)",
            color = g.ink,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
        )

        if (results.isEmpty()) {
            GCard {
                Text("Nenhuma orientação com esses filtros.", color = g.ink, fontWeight = FontWeight.Bold)
                Text(
                    "Limpe os filtros ou use os botões de busca na web / portais oficiais acima.",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        } else {
            results.forEach { guide ->
                GCard(Modifier.padding(top = 8.dp)) {
                    Text(guide.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(guide.category.label, color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(guide.howToFind, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(guide.officialHint, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(
                        "Insulinas relacionadas: ${guide.relatedInsulins.joinToString(", ")}",
                        color = g.ink,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    Text(
                        "Telefone: consulte o site oficial do estabelecimento — não exibimos números não verificados.",
                        color = g.orange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )

                    Row(
                        Modifier.padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                openWebSearch(guide.webSearchQuery)
                            },
                        ) {
                            Icon(Icons.Filled.OpenInBrowser, null, tint = g.violet, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Buscar na web", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (guide.category == EstCategory.FARMACIA_POPULAR || guide.category == EstCategory.POSTO) {
                            Text(
                                "Portal oficial",
                                color = g.blue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { openOfficialPortal(guide.category) },
                            )
                        }
                    }
                }
            }
        }

        Text(
            "Estoque muda o tempo todo. Ligue no número publicado pelo próprio estabelecimento antes de sair de casa. Este app não prescreve tratamento.",
            color = g.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
        )
    }
}
