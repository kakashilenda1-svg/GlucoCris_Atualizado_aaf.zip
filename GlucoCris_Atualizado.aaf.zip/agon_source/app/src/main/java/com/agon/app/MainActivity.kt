package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.LoadingState
import com.agon.app.ui.screens.CareScreen
import com.agon.app.ui.screens.GlucoseFormScreen
import com.agon.app.ui.screens.GlucoseListScreen
import com.agon.app.ui.screens.HistoryScreen
import com.agon.app.ui.screens.HomeScreen
import com.agon.app.ui.screens.InsulinFormScreen
import com.agon.app.ui.screens.InsulinListScreen
import com.agon.app.ui.screens.LockScreen
import com.agon.app.ui.screens.MedsScreen
import com.agon.app.ui.screens.MoreScreen
import com.agon.app.ui.screens.RemindersScreen
import com.agon.app.ui.screens.ReportScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.screens.StatsScreen
import com.agon.app.ui.screens.InsulinLocatorScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.theme.glucoColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: GlucoViewModel = viewModel()
            val data by vm.data.collectAsStateWithLifecycle()
            val ready by vm.ready.collectAsStateWithLifecycle()
            val unlocked by vm.unlocked.collectAsStateWithLifecycle()
            val dark = data.settings.darkMode ?: androidx.compose.foundation.isSystemInDarkTheme()
            AgonAppTheme(darkTheme = dark) {
                val g = glucoColors()
                val view = androidx.compose.ui.platform.LocalView.current
                if (!view.isInEditMode) {
                    SideEffect {
                        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
                        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark && ready && unlocked
                    }
                }
                when {
                    !ready -> Box(
                        Modifier
                            .fillMaxSize()
                            .background(g.bg),
                    ) { LoadingState() }
                    !unlocked -> LockScreen(vm, data.settings.displayName)
                    else -> MainApp(vm)
                }
            }
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
private fun MainApp(vm: GlucoViewModel) {
    val nav = rememberNavController()
    val g = glucoColors()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val tab = Routes.tabOf(route)
    val showBar = route == null || route in Routes.tabs
    Scaffold(
        containerColor = g.bg,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = g.card) {
                    listOf(
                        Tab(Routes.HOME, "Início", Icons.Filled.Home),
                        Tab(Routes.GLUCOSE, "Glicose", Icons.Filled.WaterDrop),
                        Tab(Routes.INSULIN, "Insulina", Icons.Filled.Vaccines),
                        Tab(Routes.REMINDERS, "Lembretes", Icons.Filled.Notifications),
                        Tab(Routes.HISTORY, "Histórico", Icons.Filled.History),
                        Tab(Routes.MORE, "Mais", Icons.Filled.MoreHoriz),
                    ).forEach { item ->
                        NavigationBarItem(
                            selected = tab == item.route,
                            onClick = { Routes.goTab(nav, item.route) },
                            icon = { Icon(item.icon, item.label) },
                            label = { Text(item.label, maxLines = 1, style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = g.violet,
                                selectedTextColor = g.violet,
                                indicatorColor = g.lilacSoft,
                                unselectedIconColor = g.muted,
                                unselectedTextColor = g.muted,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        AppNav(vm, nav, Modifier.padding(padding))
    }
}

@Composable
private fun AppNav(vm: GlucoViewModel, nav: NavHostController, modifier: Modifier) {
    NavHost(nav, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) { HomeScreen(vm, nav) }
        composable(Routes.GLUCOSE) { GlucoseListScreen(vm, nav) }
        composable(Routes.INSULIN) { InsulinListScreen(vm, nav) }
        composable(Routes.REMINDERS) { RemindersScreen(vm) }
        composable(Routes.HISTORY) { HistoryScreen(vm, nav) }
        composable(Routes.MORE) { MoreScreen(nav) }
        composable(Routes.STATS) { StatsScreen(vm, nav) }
        composable(Routes.CARE) { CareScreen(vm, nav) }
        composable(Routes.MEDS) { MedsScreen(vm, nav) }
        composable(Routes.REPORT) { ReportScreen(vm, nav) }
        composable(Routes.SETTINGS) { SettingsScreen(vm, nav) }
        composable(Routes.LOCATOR) { InsulinLocatorScreen(nav) }
        composable(
            "glicose_form?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }),
        ) { entry ->
            GlucoseFormScreen(vm, nav, entry.arguments?.getString("id"))
        }
        composable(Routes.GLUCOSE_FORM) { GlucoseFormScreen(vm, nav, null) }
        composable(
            "insulina_form?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }),
        ) { entry ->
            InsulinFormScreen(vm, nav, entry.arguments?.getString("id"))
        }
        composable(Routes.INSULIN_FORM) { InsulinFormScreen(vm, nav, null) }
    }
}

@Suppress("unused")
private val keepWhite = Color.White
