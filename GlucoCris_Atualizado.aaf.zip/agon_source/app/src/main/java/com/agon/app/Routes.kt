package com.agon.app

import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController

object Routes {
    const val HOME = "inicio"
    const val GLUCOSE = "glicose"
    const val INSULIN = "insulina"
    const val REMINDERS = "lembretes"
    const val HISTORY = "historico"
    const val MORE = "mais"
    const val STATS = "estatisticas"
    const val CARE = "cuidados"
    const val MEDS = "medicamentos"
    const val REPORT = "relatorio"
    const val SETTINGS = "ajustes"
    const val LOCATOR = "localizador"
    const val GLUCOSE_FORM = "glicose_form"
    const val INSULIN_FORM = "insulina_form"

    val tabs = listOf(HOME, GLUCOSE, INSULIN, REMINDERS, HISTORY, MORE)

    fun glucoseForm(id: String?) = if (id == null) GLUCOSE_FORM else "glicose_form?id=$id"
    fun insulinForm(id: String?) = if (id == null) INSULIN_FORM else "insulina_form?id=$id"

    fun goTab(nav: NavHostController, route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun tabOf(route: String?): String = when {
        route == null -> HOME
        route.startsWith(GLUCOSE_FORM) || route == GLUCOSE -> GLUCOSE
        route.startsWith(INSULIN_FORM) || route == INSULIN -> INSULIN
        route == REMINDERS -> REMINDERS
        route == HISTORY -> HISTORY
        route == HOME -> HOME
        else -> MORE
    }

    fun titleOf(route: String?, id: String? = null): String = when {
        route == null -> ""
        route.startsWith(GLUCOSE_FORM) -> if (id != null) "Editar glicose" else "Nova glicose"
        route.startsWith(INSULIN_FORM) -> if (id != null) "Editar insulina" else "Nova insulina"
        route == GLUCOSE -> "Glicose"
        route == INSULIN -> "Insulina"
        route == REMINDERS -> "Lembretes"
        route == HISTORY -> "Histórico"
        route == MORE -> "Organização"
        route == STATS -> "Estatísticas"
        route == CARE -> "Alimentação e sintomas"
        route == MEDS -> "Medicamentos"
        route == REPORT -> "Relatório"
        route == SETTINGS -> "Ajustes"
        route == LOCATOR -> "Localizador de Insulinas"
        else -> ""
    }
}
