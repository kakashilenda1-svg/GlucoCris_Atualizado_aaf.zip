package com.agon.app.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.GlucoStorage
import com.agon.app.data.Reminder
import com.agon.app.data.formatClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

data class SoundPreset(val id: String, val name: String, val description: String, val resId: Int)

val SOUND_PRESETS = listOf(
    SoundPreset("suave", "Suave", "Dois tons baixos e calmos", R.raw.snd_suave),
    SoundPreset("claro", "Claro", "Sequência luminosa de três notas", R.raw.snd_claro),
    SoundPreset("pulso", "Pulso", "Pulsos curtos para insulina", R.raw.snd_pulso),
    SoundPreset("alerta", "Alerta", "Tom mais presente para atenção", R.raw.snd_alerta),
)

fun presetById(id: String): SoundPreset = SOUND_PRESETS.firstOrNull { it.id == id } ?: SOUND_PRESETS[0]

object SoundPlayer {
    private var player: MediaPlayer? = null

    fun play(context: Context, id: String) {
        try {
            player?.release()
            val mp = MediaPlayer()
            val afd = context.resources.openRawResourceFd(presetById(id).resId)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            mp.setVolume(0.7f, 0.7f)
            mp.setOnCompletionListener {
                it.release()
                if (player == it) player = null
            }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            player = null
        }
    }
}

object ReminderScheduler {
    const val EXTRA_ID = "id"
    const val EXTRA_KIND = "kind"
    const val EXTRA_TITLE = "title"
    const val EXTRA_HOUR = "hour"
    const val EXTRA_MINUTE = "minute"
    const val EXTRA_DAYS = "days"
    const val EXTRA_SOUND = "sound"
    const val EXTRA_NOTES = "notes"

    fun channelId(soundId: String) = "gluco_lembretes_$soundId"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        for (preset in SOUND_PRESETS) {
            val ch = NotificationChannel(channelId(preset.id), "Lembretes · ${preset.name}", android.app.NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Lembretes de glicose e insulina com o som ${preset.name}"
            ch.enableVibration(true)
            ch.setSound(
                Uri.parse("android.resource://${context.packageName}/${preset.resId}"),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            )
            nm.createNotificationChannel(ch)
        }
    }

    fun nextTrigger(hour: Int, minute: Int, days: List<Int>, after: Long = System.currentTimeMillis()): Long? {
        if (days.isEmpty()) return null
        for (i in 0 until 8) {
            val c = Calendar.getInstance()
            c.timeInMillis = after
            c.add(Calendar.DAY_OF_YEAR, i)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if ((c.get(Calendar.DAY_OF_WEEK) - 1) in days && c.timeInMillis > after) return c.timeInMillis
        }
        return null
    }

    private fun pendingIntent(context: Context, id: String, extras: Intent?): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = "com.agon.app.REMINDER"
            data = Uri.parse("gluco://reminder/$id")
            if (extras != null) putExtras(extras)
        }
        return PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun cancel(context: Context, id: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, id, null))
    }

    fun schedule(context: Context, id: String, kind: String, title: String, hour: Int, minute: Int, days: List<Int>, soundId: String, notes: String) {
        val trigger = nextTrigger(hour, minute, days) ?: return
        val extras = Intent().apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_KIND, kind)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_HOUR, hour)
            putExtra(EXTRA_MINUTE, minute)
            putExtra(EXTRA_DAYS, days.toIntArray())
            putExtra(EXTRA_SOUND, soundId)
            putExtra(EXTRA_NOTES, notes)
        }
        val pi = pendingIntent(context, id, extras)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = if (Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    fun scheduleReminder(context: Context, r: Reminder) =
        schedule(context, r.id, r.kind, r.title, r.hour, r.minute, r.days, r.soundId, r.notes)

    fun sync(context: Context, old: List<Reminder>, new: List<Reminder>) {
        val ids = new.map { it.id }.toSet()
        old.filter { it.id !in ids }.forEach { cancel(context, it.id) }
        new.forEach { if (it.enabled) scheduleReminder(context, it) else cancel(context, it.id) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(ReminderScheduler.EXTRA_ID) ?: return
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: "glicose"
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Lembrete"
        val hour = intent.getIntExtra(ReminderScheduler.EXTRA_HOUR, 8)
        val minute = intent.getIntExtra(ReminderScheduler.EXTRA_MINUTE, 0)
        val days = intent.getIntArrayExtra(ReminderScheduler.EXTRA_DAYS)?.toList() ?: emptyList()
        val sound = intent.getStringExtra(ReminderScheduler.EXTRA_SOUND) ?: "suave"
        val notes = intent.getStringExtra(ReminderScheduler.EXTRA_NOTES) ?: ""
        ReminderScheduler.ensureChannels(context)
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
            val whenText = "$title · ${formatClock(hour, minute)}"
            val big = whenText + if (notes.isNotBlank()) "\n$notes" else ""
            val notification = NotificationCompat.Builder(context, ReminderScheduler.channelId(sound))
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle(if (kind == "glicose") "Hora de medir a glicose" else "Hora da insulina")
                .setContentText(whenText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(big))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(context, id.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                .build()
            try {
                NotificationManagerCompat.from(context).notify(id.hashCode(), notification)
            } catch (e: SecurityException) {
            }
        }
        ReminderScheduler.schedule(context, id, kind, title, hour, minute, days, sound, notes)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val data = GlucoStorage.read(context)
                data?.reminders?.filter { it.enabled }?.forEach { ReminderScheduler.scheduleReminder(context, it) }
            } catch (e: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}

