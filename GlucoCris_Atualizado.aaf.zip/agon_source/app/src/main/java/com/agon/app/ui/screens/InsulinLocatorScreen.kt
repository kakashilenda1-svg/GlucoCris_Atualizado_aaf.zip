package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors

// ==================== Modelos locais do localizador ====================

private enum class EstCategory(val label: String) {
    TODOS("Todos os locais"),
    POSTO("Postos de saúde (UBS)"),
    FARMACIA_PUBLICA("Farmácias públicas"),
    FARMACIA_PARTICULAR("Farmácias particulares"),
    FARMACIA_POPULAR("Farmácia Popular"),
}

private data class DemoEstablishment(
    val id: String,
    val name: String,
    val category: EstCategory,
    val address: String,
    val city: String,
    val state: String,
    val phone: String?,
    val hours: String?,
    val insulins: List<String>,
    val stockNote: String = "Estoque não confirmado — ligue antes de ir",
    val source: String = "Dados demonstrativos (não reais)",
)

private val DEMO_ESTABLISHMENTS = listOf(
    DemoEstablishment(
        "d1",
        "UBS Exemplo Centro (DEMONSTRATIVO)",
        EstCategory.POSTO,
        "Rua Exemplo, 100 — Centro",
        "São Paulo",
        "SP",
        "(11) 3000-0000",
        "Seg–Sex 07:00–17:00",
        listOf("Insulina Humana Regular", "Insulina Humana NPH"),
    ),
    DemoEstablishment(
        "d2",
        "Farmácia Popular Exemplo (DEMONSTRATIVO)",
        EstCategory.FARMACIA_POPULAR,
        "Av. Exemplo, 500 — Centro",
        "Rio de Janeiro",
        "RJ",
        "(21) 3000-0000",
        "Seg–Sáb 08:00–18:00",
        listOf("Insulina glargina (Lantus)", "Insulina degludeca (Tresiba)"),
    ),
    DemoEstablishment(
        "d3",
        "Farmácia Particular Exemplo (DEMONSTRATIVO)",
        EstCategory.FARMACIA_PARTICULAR,
        "Rua Comercial, 200 — Savassi",
        "Belo Horizonte",
        "MG",
        "(31) 3000-0000",
        "24 horas",
        listOf("Insulina lispro (Humalog)", "Insulina asparte (NovoRapid)", "Insulina glargina"),
    ),
    DemoEstablishment(
        "d4",
        "Farmácia Pública Municipal Exemplo (DEMONSTRATIVO)",
        EstCategory.FARMACIA_PUBLICA,
        "Praça Central, 50",
        "Curitiba",
        "PR",
        "(41) 3000-0000",
        "Seg–Sex 08:00–17:00",
        listOf("Insulina Humana NPH", "Insulina Humana Regular"),
    ),
)

private val INSULIN_TYPES_EDU = listOf(
    "Insulina humana Regular — geralmente de ação curta",
    "Insulina humana NPH — geralmente de ação intermediária",
    "Análogos de ação rápida/ultrarrápida (lispro, asparte, glulisina)",
    "Análogos de ação prolongada/basal (glargina, detemir, degludeca)",
    "Pré-misturas e outras formulações oficialmente reconhecidas",
)

private val BRAZIL_STATES = listOf(
    "Todos", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO",
    "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI",
    "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
)

@Composable
fun InsulinLocatorScreen(nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current

    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(EstCategory.TODOS) }
    var stateFilter by remember { mutableStateOf("Todos") }
    var cityFilter by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }

    val results = remember(query, category, stateFilter, cityFilter) {
        DEMO_ESTABLISHMENTS.filter { est ->
            val matchCat = category == EstCategory.TODOS || est.category == category
            val matchState = stateFilter == "Todos" || est.state.equals(stateFilter, ignoreCase = true)
            val matchCity = cityFilter.isBlank() || est.city.contains(cityFilter, ignoreCase = true)
            val matchQuery = query.isBlank() ||
                est.name.contains(query, ignoreCase = true) ||
                est.insulins.any { it.contains(query, ignoreCase = true) } ||
                est.city.contains(query, ignoreCase = true)
            matchCat && matchState && matchCity && matchQuery
        }
    }

    ScrollScreen {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "← Voltar",
                color = g.violet,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.clickable { nav.popBackStack() },
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("Localizador de Insulinas 💉", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text(
            "Busca nacional — todos os estados do Brasil",
            color = g.muted,
            fontSize = 13.sp,
        )

        // Aviso crítico
        GCard(Modifier.padding(top = 12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.Info, null, tint = g.orange, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        "Encontrar um local NÃO confirma estoque atual.",
                        color = g.ink,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                    Text(
                        "Sempre ligue antes de se dirigir ao estabelecimento. Os dados abaixo são DEMONSTRATIVOS e não representam disponibilidade real.",
                        color = g.muted,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        // Busca
        GField(
            "Buscar insulina, princípio ativo, marca ou local",
            query,
            { query = it },
            "Ex: glargina, NPH, Lantus…",
        )

        // Categoria
        Text("Categoria do estabelecimento", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
        ChipRow(
            EstCategory.entries.map { it.name to it.label },
            category.name,
        ) { key ->
            category = EstCategory.entries.first { it.name == key }
        }

        // Estado
        Text("Estado (UF)", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        ChipRow(
            BRAZIL_STATES.map { it to it },
            stateFilter,
        ) { stateFilter = it }

        // Município
        GField("Município (opcional)", cityFilter, { cityFilter = it }, "Ex: Campinas, Interior…")

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            PrimaryButton("Limpar filtros", g.muted, {
                query = ""
                category = EstCategory.TODOS
                stateFilter = "Todos"
                cityFilter = ""
            }, Modifier.weight(1f))
            PrimaryButton(
                if (showInfo) "Ocultar tipos" else "Tipos de insulina",
                g.violetDeep,
                { showInfo = !showInfo },
                Modifier.weight(1f),
            )
        }

        if (showInfo) {
            GCard(Modifier.padding(top = 10.dp)) {
                Text("Classificação educativa (fontes oficiais)", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Não recomenda dose, horário, troca ou tratamento. Início, pico e duração variam conforme formulação, pessoa e orientação profissional.",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
                INSULIN_TYPES_EDU.forEach {
                    Text("• $it", color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }

        // Contagem
        Text(
            "${results.size} resultado(s)",
            color = g.ink,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
        )

        if (results.isEmpty()) {
            GCard {
                Text("Nenhum estabelecimento encontrado com os filtros atuais.", color = g.ink, fontWeight = FontWeight.Bold)
                Text(
                    "Ausência de resultado não prova que o local ou a insulina não existam. Tente ampliar os filtros ou buscar em outro município/estado.",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        } else {
            results.forEach { est ->
                GCard(Modifier.padding(top = 8.dp)) {
                    Text(est.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(est.category.label, color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("${est.address}", color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Text("${est.city} — ${est.state}", color = g.muted, fontSize = 13.sp)
                    est.hours?.let {
                        Text("Horário: $it", color = g.muted, fontSize = 12.sp)
                    }
                    Text(est.stockNote, color = g.orange, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("Insulinas (referência): ${est.insulins.joinToString(", ")}", color = g.ink, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Text("Fonte: ${est.source}", color = g.muted, fontSize = 11.sp)

                    Row(
                        Modifier.padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        if (est.phone != null) {
                            Text(
                                "Ligar",
                                color = g.violet,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${est.phone}"))
                                    context.startActivity(intent)
                                },
                            )
                        }
                        Text(
                            "Rota",
                            color = g.blue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                val q = Uri.encode("${est.address}, ${est.city} - ${est.state}")
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q"))
                                context.startActivity(intent)
                            },
                        )
                    }
                }
            }
        }

        // Rodapé educativo
        Text(
            "Este localizador não prescreve tratamento e não confirma estoque. Confirme sempre com o estabelecimento e com sua equipe de saúde.",
            color = g.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
        )
    }
}
