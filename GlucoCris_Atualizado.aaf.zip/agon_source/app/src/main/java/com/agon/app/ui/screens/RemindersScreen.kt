package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Reminder
import com.agon.app.data.WEEKDAYS
import com.agon.app.data.daysLabel
import com.agon.app.data.formatClock
import com.agon.app.data.uid
import com.agon.app.reminders.SOUND_PRESETS
import com.agon.app.reminders.SoundPlayer
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors

@Composable
fun RemindersScreen(vm: GlucoViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var creating by remember { mutableStateOf(false) }
    var confirmId by remember { mutableStateOf<String?>(null) }

    ScrollScreen {
        Text("Lembretes", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        Text(
            "Os lembretes tocam e enviam notificação no minuto configurado, mesmo com o Gluco Cris ❤️ fechado. Cada um tem som próprio.",
            color = g.muted,
            fontSize = 13.sp,
        )
        Text("Crie horários flexíveis para glicose e insulina.", color = g.muted, fontSize = 13.sp)
        PrimaryButton("Novo lembrete", g.violet, { creating = true; editing = null }, Modifier.padding(top = 12.dp))

        if (data.reminders.isEmpty()) {
            EmptyState("Sem lembretes", "Nenhum lembrete ativo.")
        }
        data.reminders.sortedWith(compareBy({ it.hour }, { it.minute })).forEach { r ->
            GCard(Modifier.padding(top = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text("${formatClock(r.hour, r.minute)} · ${daysLabel(r.days)}", color = g.muted, fontSize = 12.sp)
                        Text(if (r.kind == "glicose") "Medir glicose" else "Aplicar insulina", color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (r.notes.isNotBlank()) Text(r.notes, color = g.ink, fontSize = 13.sp)
                    }
                    Switch(checked = r.enabled, onCheckedChange = { vm.toggleReminder(r.id) })
                }
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Editar", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { editing = r; creating = false })
                    Text("Ouvir som", color = g.blue, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { SoundPlayer.play(context, r.soundId) })
                    Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { confirmId = r.id })
                }
            }
        }

        if (creating || editing != null) {
            ReminderForm(
                initial = editing,
                onCancel = { creating = false; editing = null },
                onSave = {
                    vm.saveReminder(it)
                    creating = false
                    editing = null
                },
            )
        }
    }
    confirmId?.let { id ->
        ConfirmDialog("Excluir lembrete", "Esta ação não pode ser desfeita.", "Excluir", {
            vm.deleteReminder(id)
            confirmId = null
        }) { confirmId = null }
    }
}

@Composable
private fun ReminderForm(initial: Reminder?, onCancel: () -> Unit, onSave: (Reminder) -> Unit) {
    val g = glucoColors()
    val context = LocalContext.current
    var title by remember(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var kind by remember(initial?.id) { mutableStateOf(initial?.kind ?: "glicose") }
    var hour by remember(initial?.id) { mutableStateOf(initial?.hour?.toString() ?: "8") }
    var minute by remember(initial?.id) { mutableStateOf(initial?.minute?.toString()?.padStart(2, '0') ?: "00") }
    var days by remember(initial?.id) { mutableStateOf(initial?.days?.toSet() ?: setOf(1, 2, 3, 4, 5)) }
    var sound by remember(initial?.id) { mutableStateOf(initial?.soundId ?: "suave") }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    GCard(Modifier.padding(top = 14.dp)) {
        Text(if (initial == null) "Novo lembrete" else "Editar lembrete", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        GField("Título", title, { title = it }, "Ex.: Glicemia em jejum")
        Text("Tipo", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        ChipRow(listOf("glicose" to "Medir glicose", "insulina" to "Aplicar insulina"), kind) { kind = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GField("Hora", hour, { hour = it }, "8", numeric = true)
            GField("Minuto", minute, { minute = it }, "00", numeric = true)
        }
        Text("Dias da semana", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            WEEKDAYS.forEachIndexed { index, label ->
                val on = index in days
                Text(
                    label,
                    color = if (on) androidx.compose.ui.graphics.Color.White else g.ink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { days = if (on) days - index else days + index }
                        .padding(2.dp),
                )
            }
        }
        Text("Som do alerta", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        SOUND_PRESETS.forEach { preset ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { sound = preset.id }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (sound == preset.id) "●" else "○", color = g.violet, modifier = Modifier.padding(end = 6.dp))
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text(preset.name, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(preset.description, color = g.muted, fontSize = 12.sp)
                }
                Text("Ouvir", color = g.blue, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { SoundPlayer.play(context, preset.id) })
            }
        }
        GField("Observações", notes, { notes = it }, "Opcional")
        error?.let { Text(it, color = g.red, fontSize = 13.sp) }
        PrimaryButton(if (initial == null) "Salvar lembrete" else "Salvar alterações", g.violet, {
            val h = hour.toIntOrNull()
            val m = minute.toIntOrNull()
            error = when {
                title.isBlank() -> "Dê um título ao lembrete."
                days.isEmpty() -> "Escolha ao menos um dia."
                h == null || h !in 0..23 -> "Hora inválida."
                m == null || m !in 0..59 -> "Minuto inválido."
                else -> null
            }
            if (error == null && h != null && m != null) {
                onSave(Reminder(initial?.id ?: uid(), kind, title.trim(), h, m, days.sorted(), initial?.enabled ?: true, sound, notes.trim()))
            }
        }, Modifier.padding(top = 8.dp))
        PrimaryButton("Cancelar edição", g.muted, onCancel, Modifier.padding(top = 8.dp))
    }
}
